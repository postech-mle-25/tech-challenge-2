"""
AWS Lambda function para trigger automático de Glue Jobs
Acionada por eventos S3 quando novos arquivos são adicionados na pasta raw/
"""

import json
import os
import boto3
import logging
from datetime import datetime

# Configurar logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Inicializar cliente Glue
glue_client = boto3.client('glue')

def start_glue_job(job_name, bucket_name, file_key):
    """
    Inicia um job do Glue com parâmetros específicos
    
    Args:
        job_name (str): Nome do job do Glue
        bucket_name (str): Nome do bucket S3
        file_key (str): Chave do arquivo que disparou o trigger
    
    Returns:
        dict: Informações sobre o job iniciado
    """
    try:
        logger.info(f"Iniciando Glue job: {job_name}")
        
        # Parâmetros específicos para este job
        job_arguments = {
            '--source-bucket': bucket_name,
            '--target-bucket': bucket_name,
            '--triggered-by-file': file_key,
            '--execution-timestamp': datetime.now().isoformat()
        }
        
        # Iniciar o job
        response = glue_client.start_job_run(
            JobName=job_name,
            Arguments=job_arguments
        )
        
        job_run_id = response['JobRunId']
        logger.info(f"Job iniciado com sucesso. RunId: {job_run_id}")
        
        # Obter status inicial
        status_response = glue_client.get_job_run(
            JobName=job_name,
            RunId=job_run_id
        )
        
        job_status = status_response['JobRun']['JobRunState']
        
        return {
            'job_run_id': job_run_id,
            'job_status': job_status,
            'job_name': job_name
        }
        
    except Exception as e:
        logger.error(f"Erro ao iniciar job {job_name}: {str(e)}")
        raise

def lambda_handler(event, context):
    """
    Handler principal da Lambda
    
    Args:
        event: Evento S3 com informações do arquivo
        context: Contexto da execução Lambda
    
    Returns:
        dict: Resposta da execução
    """
    try:
        # Obter nome do job das variáveis de ambiente
        job_name = os.environ.get("JOB_NAME")
        if not job_name:
            raise ValueError("Variável de ambiente JOB_NAME não configurada")
        
        # Extrair informações do evento S3
        if not event.get('Records'):
            raise ValueError("Evento S3 inválido: nenhum record encontrado")
        
        record = event['Records'][0]
        bucket_name = record['s3']['bucket']['name']
        file_key = record['s3']['object']['key']
        event_name = record['eventName']
        
        logger.info(f"Evento S3 recebido:")
        logger.info(f"  - Bucket: {bucket_name}")
        logger.info(f"  - Arquivo: {file_key}")
        logger.info(f"  - Evento: {event_name}")
        
        # Validar se o arquivo está na pasta raw/
        if not file_key.startswith('raw/'):
            logger.info(f"Arquivo ignorado - não está na pasta raw/: {file_key}")
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'Arquivo ignorado - fora da pasta raw/',
                    'file': file_key
                })
            }
        
        # Validar se é um arquivo parquet
        if not file_key.endswith('.parquet'):
            logger.info(f"Arquivo ignorado - não é parquet: {file_key}")
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'Arquivo ignorado - não é parquet',
                    'file': file_key
                })
            }
        
        # Iniciar o job do Glue
        logger.info(f"Iniciando processamento para arquivo: {file_key}")
        job_info = start_glue_job(job_name, bucket_name, file_key)
        
        # Resposta de sucesso
        response = {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Glue job iniciado com sucesso',
                'job_run_id': job_info['job_run_id'],
                'job_status': job_info['job_status'],
                'job_name': job_info['job_name'],
                'triggered_by': file_key,
                'timestamp': datetime.now().isoformat()
            })
        }
        
        logger.info(f"Lambda executada com sucesso: {job_info}")
        return response
        
    except Exception as e:
        error_message = f"Erro na execução da Lambda: {str(e)}"
        logger.error(error_message)
        
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e),
                'timestamp': datetime.now().isoformat()
            })
        }
